// 확장에선 로그인 세션을 chrome.storage 에 둔다 → 팝업과 배지(백그라운드)가 같은 로그인을 씀
globalThis.SB_OPTIONS = {
  auth: {
    storage: {
      getItem: async (k) => (await chrome.storage.local.get(k))[k] ?? null,
      setItem: (k, v) => chrome.storage.local.set({ [k]: v }),
      removeItem: (k) => chrome.storage.local.remove(k),
    },
    persistSession: true, autoRefreshToken: true, detectSessionInUrl: false,
  },
};
