// 🧩 압축해제 설치라 크롬이 자동 업데이트를 안 함 → 사이트의 최신 번호(tools/build-extension.sh 가 씀)와 비교해 팝업 위에 안내. 못 읽으면 조용히 넘어감
(async () => {
  const cur = chrome.runtime.getManifest().version;
  const latest = (await fetch(`${PLANNER}extension-version.txt`, { cache: "no-store" }).then((r) => (r.ok ? r.text() : "")).catch(() => "")).trim();
  if (!/^\d+(\.\d+)+$/.test(latest) || latest.localeCompare(cur, undefined, { numeric: true }) <= 0) return;
  const box = document.getElementById("extUpd");
  box.innerHTML = `<b>🧩 새 버전 ${latest}이 있어요</b> <small>(지금 ${cur})</small> <a href="${PLANNER}files/pallo-planner-extension.zip" download>받기 ↓</a><br><small>압축을 풀고 chrome://extensions 에서 지금 확장을 삭제한 뒤, 개발자 모드 → '압축해제된 확장 프로그램 로드'로 그 폴더를 고르세요. 삭제하면 다시 로그인해야 해요.</small>`;
  box.classList.remove("hidden");
})();
