// 툴바 아이콘 배지: 오늘 남은 개수(고정업무 + 할 일 + 팀 업무). 🔥 꼭 할 일이나 지난 데드라인이 있으면 빨강
importScripts("supabase.min.js", "config.js", "week.js", "ext-auth.js");
const sb = supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_KEY, SB_OPTIONS);
const applies = (it, day) => { const d = W.parse(day); return it.days.includes(d.getDay()) && (!it.weeks || it.weeks.includes(Math.floor((d.getDate() - 1) / 7) + 1)) && (!it.from_day || day >= it.from_day) && (!it.to_day || day <= it.to_day); }; // widget.js 와 같게

async function badge() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { chrome.action.setBadgeText({ text: "" }); chrome.action.setTitle({ title: "팔로 플래너 — 눌러서 로그인" }); return; }
  const me = session.user.id, day = W.ymd(new Date());
  const [p, t, k, r, c, d] = await Promise.all([
    sb.from("profiles").select("role").eq("user_id", me).maybeSingle(),
    sb.from("tasks").select("done, must_do").eq("user_id", me).eq("day", day).neq("title", ""),
    sb.rpc("team_tasks_between", { p_from: day, p_to: day }),
    sb.from("routine_items").select("id, days, weeks, from_day, to_day"),
    sb.rpc("team_routine_checks_on", { p_day: day }), // 고정업무 체크는 지점 공용(옛 routine_checks 는 10-21 이후 안 씀)
    sb.from("tasks").select("id").eq("user_id", me).eq("done", false).lt("deadline", new Date().toISOString()).limit(20),
  ]);
  if (t.error || r.error) return; // 네트워크 끊김 등: 이전 배지 유지
  const admin = p.data?.role === "admin", checks = new Set((c.data ?? []).map((x) => x.item_id));
  const rt = admin ? 0 : (r.data ?? []).filter((it) => applies(it, day) && !checks.has(it.id)).length;
  const todo = t.data.filter((x) => !x.done).length, team = admin ? 0 : (k.data ?? []).filter((x) => !x.done_by).length;
  const hot = t.data.some((x) => x.must_do && !x.done) || (d.data ?? []).length > 0, left = rt + todo + team;
  chrome.action.setBadgeText({ text: left ? String(left) : "✓" });
  chrome.action.setBadgeBackgroundColor({ color: hot ? "#ff4d4f" : left ? "#8b6fd6" : "#4dab9a" });
  chrome.action.setTitle({ title: `팔로 플래너 — 📌 매니저체크리스트 ${rt} · ✅ 할 일 ${todo} · 👥 팀 ${team} 남음${hot ? " · 🔥/⏰ 확인 필요" : ""}` });
}
chrome.alarms.create("badge", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(badge);
chrome.runtime.onStartup.addListener(badge);
chrome.runtime.onInstalled.addListener(badge);
chrome.runtime.onMessage.addListener((m) => { if (m === "badge") badge(); });
